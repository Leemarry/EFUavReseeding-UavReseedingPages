var PLATFROM_CONFIG = {};
PLATFROM_CONFIG.baseUrl = "请在这里输入访问地址"