module.exports={type:"commonjs"};
